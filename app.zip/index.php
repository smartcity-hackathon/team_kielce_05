<!DOCTYPE html>
<html>
<head>
	<title>Poznaj Kielce!</title>
	<meta charset="utf8">
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div id="mobile">
		<div id="header">Poznaj.Kielce.pl</div>

		<iframe src="logowanie.html" style="display: none;"></iframe>
		<iframe src="aplikacja/index.php" style="margin-top: 40px; width: 100%; height: calc(100% - 40px); border: none; padding: 0; margin: 0;line-height: 0;"></iframe>
	</div>
</body>
</html>