<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->library('user_agent');
		/*if(!$this->agent->is_mobile()) {
			die('<h1>Aplikacja dostepna tylko na urzadzeniach mobilnych :[</h1>');
		}*/
		if($this->Gracz->is_logged()) {
			if($this->Gracz->get_current_place()) {
				$data = $this->Atrakcja->get_place($this->Gracz->get_current_place());
				$this->load->view('current.php', $data);
			} else {
				$this->load->view('main');				
			}

		} else {
			if($this->Gracz->login('Test', 'test')) {
				echo 'Zalogowano';
			} else {
				echo 'Jakis blad i nie wiem gdzie';
			}
		}
	}

	public function gra() {
		if($this->Gracz->is_logged()) {
			$this->load->view('choosegame');
		} else {
			if($this->Gracz->login('Test', 'test')) { 
				$this->load->view('logowanie');
			} else {
				
			}
		}		
	}

	public function graj_sam($id=-1) {
		if($this->Gracz->is_logged()) {
			if($id == -1) {
				$this->load->view('choose');				
			} else {
				$this->load->model('Atrakcja');
				$x = $this->Atrakcja->new_place($this->Gracz->get_id(), $id);
				$this->load->helper('url');
				redirect('/Welcome');
			}

		} else {
			if($this->Gracz->login('Test', 'test')) { 
				
			} else {
				
			}
		}		
	}

    public function noop() {
        $this->load->view('noop');
    }

	public function poddaj_sie() {
		$this->Gracz->reset_place();
		$this->load->helper('url');
		redirect('/Welcome');		
	}

	public function udostepnij() {
		$this->load->view('share');
	}
	
	public function graj_ze_znajomym() {
		$this->load->view('play_with_friend');
	}
	public function losuj_przeciwnika() {
		$this->load->view('random_opponent');

	}

	public function na_miejscu() {
		if($this->Gracz->is_logged()) {
			if($this->Gracz->get_current_place() > 0) {
				if(1==1) //jeżeli zgadzają się koordynaty
				{

					$data['punkty'] = rand(5,15);
					//$this->db->query("INSERT INTO `gracze_atrakcje` VALUES('NULL', '".$this->Gracz->get_id()."', '".$this->Gracz->get_current_place()."', '".time()."', '".$data['punkty']."')");
                    $x = $this->Atrakcja->get_place($this->Gracz->get_current_place());
					$this->db->query("UPDATE `gracze` SET `Punkty` = `Punkty` + '".$data['punkty']."' WHERE `ID` = '".$this->Gracz->get_id()."'");
                    
                    $data['odleglosc'] = $this->Atrakcja->distance($x['KoordynatyX'], $x['KoordynatyY']);
					$this->load->view('place_successful', $data);
					//$this->Gracz->reset_place();
				} else {

				}
			} else {
				$this->load->view('main');		
			}

		} else {
			if($this->Gracz->login('Test', 'test')) { 
				
			} else {
				
			}
		}			
	}
}
