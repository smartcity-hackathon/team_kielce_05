<!DOCTYPE html>
<html>
<head>
	<title>Eldo</title>
	<style>*, *::after, *::before {
	margin: 0;
	padding: 0;
	box-sizing: border-box;
}
		body {
			font-family: Verdana, sans-serif;

			background-image: url('http://bartek.pl/img/bg.jpg');

			background-size: 100% 100%;
			background-repeat: no-repeat;
			background-attachment: fixed;
		}

		.container { width: 100%;}

		.container header {
			height: 150px;
			text-align: center;
		}

		.container #burgermenu {
			width: 100%;
			height: 40px;
			background-color: #2a9dd9;
			text-align: right;
		}
        .container footer {
			position:absolute;
			bottom:0;
			width:100%;
			height:40px;
			background:#464955;
			line-height: 40px;
			text-align: center;
		}
	</style>
</head>
<body>
	<div class="container">
		<div id="burgermenu">
			<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Hamburger_icon.svg/1200px-Hamburger_icon.svg.png" width="40px" height="40px">&nbsp;&nbsp;
		</div>
		<header style="margin-bottom: 15px;">
			<img src="http://bartek.pl/img/logo.png"  height="150px" style="margin-bottom: 10px;">
		</header>
		<article style="text-align: center;">
			<p style="background-color: rgba(255,255,255,0.2); padding: 10px;">
				Podziel się naszą aplikacją ze znajomymi!
			</p>

		</article>
		<article style="text-align: center;">
			<input type="button" value="Udostępnij na Facebooku" style="margin-top: 20px;width: 65%; height: 50px; font-size: 1.7em; border-radius: 10px; background-color: #27BCC2; border: none; text-decoration: none;display: inline-block;">
			<input type="button" value="Udostępnij na Twitterze" style="margin-top: 20px;width: 65%; height: 50px; font-size: 1.7em; border-radius: 10px; background-color: #27BCC2; border: none; text-decoration: none;display: inline-block;">
			<input type="button" value="Wróć!" style="margin-top: 20px;width: 65%; height: 50px; font-size: 1.7em; border-radius: 10px; background-color: #27BCC2; border: none; text-decoration: none;display: inline-block;" onclick="window.location='/aplikacja/index.php/Welcome';"
		</article>

		<footer>
			Poznaj Kielce &copy; 2018
		</footer>
	</div>
</body>
</html>
