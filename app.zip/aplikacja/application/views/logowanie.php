<!DOCTYPE html>
<html>
<head>
	<title>Eldo</title>
	<style>*, *::after, *::before {
	margin: 0;
	padding: 0;
	box-sizing: border-box;
}
		body {
			font-family: Verdana, sans-serif;

			background-image: url('bg.jpg');
			background-size: 100% 100%;
			background-repeat: no-repeat;
			background-attachment: fixed;
		}

		.container { width: 100%;}

		.container header {
			height: 150px;
			text-align: center;
		}

		.container #burgermenu {
			width: 100%;
			height: 40px;
			background-color: #2a9dd9;
			text-align: right;
		}
        .container footer {
			position:absolute;
			bottom:0;
			width:100%;
			height:40px;
			background:#464955;
			line-height: 40px;
			text-align: center;
		}
	</style>
</head>
<body>
	<div class="container">
		<div id="burgermenu">
			<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Hamburger_icon.svg/1200px-Hamburger_icon.svg.png" width="40px" height="40px">&nbsp;&nbsp;
		</div>
		<header style="margin-bottom: 15px;">
			<img src="http://bartek.pl/img/logo.png"  height="150px" style="margin-bottom: 10px;">
		</header>

		<article style="text-align: center;">
			<h1 style="margin: 0; padding: 0; background-color: rgba(255,255,255,0.2); padding: 10px;">Dołącz i eksploruj razem z nami!</h1>
			<input type="button" value="Dołącz!" style="margin-top: 20px;width: 65%; height: 50px; font-size: 1.7em; border-radius: 10px; background-color: #27BCC2; border: none; text-decoration: none;display: inline-block;">
		</article>

		<footer>
			Poznaj Kielce &copy; 2018
		</footer>
	</div>
</body>
</html>