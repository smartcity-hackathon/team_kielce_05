<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Atrakcja extends CI_Model {

	public function get_place($id) {
		$query = $this->db->query("SELECT *	FROM `atrakcje` WHERE `ID` = '".$id."' LIMIT 1;");

		return $query->row_array();
	}

	public function new_place($player, $cat=0) {
		    if($cat == 0) {
			    $q = "SELECT * FROM `atrakcje` ORDER BY rand() LIMIT 1;";
		    } else {
			    $q = "SELECT * FROM `atrakcje` WHERE `Kategoria` = '".$cat."' ORDER BY rand() LIMIT 1;";
		    }
		    $query = $this->db->query($q);
		    $w = $query->row_array();
		    $query2 = $this->db->query("SELECT * FROM `gracze_atrakcje` WHERE `Gracz` = '".$player."' AND `Atrakcje` = '".$w['ID']."'");

		    if($query2->num_rows() == 0) {
			    $this->db->query("UPDATE `gracze` SET `AktualnaAtrakcja` = '".$w['ID']."' WHERE `ID` = '".$player."'");
		    }

         
            $this->session->set_userdata('time', $this->session->userdata('time')+1);
		    return ($query2->num_rows() > 0) ? $this->new_place($player, $cat) : 93;
	}
    public function distance($lat1, $lon1, $lat2=50.900517, $lon2=20.589510, $unit="K") {

      $theta = $lon1 - $lon2;
      $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
      $dist = acos($dist);
      $dist = rad2deg($dist);
      $miles = $dist * 60 * 1.1515;
      $unit = strtoupper($unit);

      if ($unit == "K") {
          return ($miles * 1.609344);
      } else if ($unit == "N") {
          return ($miles * 0.8684);
      } else {
          return $miles;
      }
    }

} 
