<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gracz extends CI_Model {

	public function is_logged() {
		return ($this->session->userdata('logged') > 0) ? true : false;
	}

	public function get_id() {
		return ($this->is_logged()) ? $this->session->userdata('logged') : false;
	}

	public function get_data() {
		if($this->is_logged() === false) {
			return false;
		}
		$query = $this->db->query("SELECT *	FROM `gracze` WHERE `ID` = '".$this->get_id()."' LIMIT 1;");

		return $query->row();

	}

	public function login($login, $password) {
		if($this->is_logged()) {
			return false;
		}
		$query = $this->db->query("SELECT *	FROM `gracze` WHERE `Login` = '".$login."' AND `Haslo` = '".$password."' LIMIT 1;");

		if($query->num_rows($query)) {
			$row = $query->row();
			$this->session->set_userdata('logged', $row->ID);
			return true;
		} else {
			return false;
		}
	}	

	public function register($login, $password) {
		if($this->is_logged()) {
			return false;
		}
		$query = $this->db->query("INSERT INTO `gracze` VALUES('NULL', '".$login."', '".$password."', 'NULL', 'NULL')");

	}

	public function get_all_points() {
		if($this->is_logged() === false) {
			return false;
		}
		$m = $this->get_data();
		return $m->points;
	}

	public function get_month_points() {
		if($this->is_logged() === false) {
			return false;
		}

		$current_time = time().'';
		$q = $this->db->query(
			"SELECT * FROM `gracze_atrakcje` WHERE `Gracz` = '".$this->get_id()."' AND `Czas` > '".($current_time - 3600*24*30)."'");

		$points = 0;
		foreach ($q->result() as $row) {
			$points += $row->Punkty;
		}
		return $points;
	}

	public function get_week_points() {
		if($this->is_logged() === false) {
			return false;
		}

		$current_time = time().'';
		$q = $this->db->query("SELECT * FROM `gracze_atrakcje` WHERE `Gracz` = '".$this->get_id()."' AND `Czas` > '".($current_time - 3600*24*7)."'");

		$points = 0;
		foreach ($query->result() as $row) {
			$points += $row->Punkty;
		}
		return $points;
	}
	public function get_day_points() {
		if($this->is_logged() === false) {
			return false;
		}

		$current_time = time().'';
		$q = $this->db->query("SELECT * FROM `gracze_atrakcje` WHERE `Gracz` = '".$this->get_id()."' AND `Czas` > '".($current_time - 3600*24)."'");

		$points = 0;
		foreach ($query->result() as $row) {
			$points += $row->Punkty;
		}
		return $points;
	}

	public function get_current_place() {
		if($this->is_logged() === false) {
			return false;
		}
		$m = $this->get_data();
		return $m->AktualnaAtrakcja;		
	}

	public function reset_place() {
		$this->db->query("UPDATE `gracze` SET `AktualnaAtrakcja` = '0' WHERE `ID` = '".$this->get_id()."'");
	}
}